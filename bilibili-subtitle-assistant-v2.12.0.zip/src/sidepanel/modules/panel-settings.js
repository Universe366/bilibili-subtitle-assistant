// 设置面板：全部配置都在侧边栏内完成（不另开设置标签页）。
// 要点：官网/申请 Key 链接、测试连接、探测模型（可点击标签）、自定义地址申请域名权限、
//       密钥掩码 + 留空不改动、显式保存按钮、构建指纹、诊断可复制、
//       展开状态与滚动位置在重建后恢复（稳定性 #5）。

import {
  h,
  clear,
  button,
  collapsible,
  field,
  textInput,
  numberInput,
  select,
  checkbox,
  toast,
  fmtBytes,
  fmtRelative,
  copyText
} from './dom.js';
import { store, loadSettings, saveSettings } from './store.js';
import { call } from './bridge.js';
import { app, showError, loadHistory, restoreHistory, removeHistory, clearHistory, persistSettings, doProviderSearch, doEngineSearch } from './context.js';
import { openOverlay, closeOverlays, confirmDialog, promptDialog } from './ui.js';
import { SEARCH_ENGINES, EXPORT_FORMATS, EXPORT_TEMPLATES, DEFAULT_SYSTEM_PROMPT } from '../../shared/constants.js';
import { exportRuleGroups, parseRuleGroups } from './optimize.js';
import { downloadFile } from './dom.js';
import { batchAdd, batchRemove, batchCancel, batchPause, batchClearDone, expandCollectionsFromText } from './context.js';
import * as SKILLS from '../../shared/skills.js';
import { TIME_PRESETS, normalizeTimeRange } from '../../shared/time-range.js';

const state = {
  host: null,
  scrollHost: null,
  dirty: false,
  draft: null,
  modelCache: {},
  // 设置页搜索：只过滤视图，不改变任何配置
  query: '',
  searchInput: null,
  searchCount: null,
  clearBtn: null,
  noResult: null,
  preSearchOpen: null
};

// 面板侧也需要知道「另一个站点」的地址，用于一键切换接口地址。
// 与后台 providers.js 的 alternateHosts 保持同样的白名单。
const DUAL_TLD_HOSTS = [/^api\.siliconflow\.(cn|com)$/i];

// 「配置状态」里的 area → 设置分组 key，用于「去配置」跳转。
const AREA_GROUP = {
  ai: 'ai',
  asr: 'asr',
  search: 'search',
  prompt: 'prompt',
  general: 'general',
  export: 'export',
  mcp: 'mcp'
};

function hostOf(url) {
  try {
    return new URL(String(url || '')).hostname;
  } catch (err) {
    return '';
  }
}

function alternateHostsForUi(baseUrl) {
  const raw = String(baseUrl || '').trim();
  if (!raw) return [];
  try {
    const u = new URL(raw);
    if (!DUAL_TLD_HOSTS.some((re) => re.test(u.hostname))) return [];
    const alt = /\.cn$/i.test(u.hostname) ? u.hostname.replace(/\.cn$/i, '.com') : u.hostname.replace(/\.com$/i, '.cn');
    return [{ host: alt, url: `${u.protocol}//${alt}${u.pathname.replace(/\/+$/, '')}` }];
  } catch (err) {
    return [];
  }
}

export function init(container) {
  const root = h('div', { class: 'pane', style: { display: 'flex', flexDirection: 'column', height: '100%', minHeight: '0' } });
  const toolbar = h('div', { class: 'pane-toolbar' });
  const searchBar = h('div', { class: 'settings-search' });
  const searchInput = textInput(
    '',
    (v) => {
      state.query = v;
      applyFilter();
    },
    { placeholder: '搜索设置项：Key / 导出 / 超时 / MCP…' }
  );
  searchInput.id = 'settings-search';
  searchInput.setAttribute('aria-label', '搜索设置项');
  const clearBtn = button(
    '清除',
    () => {
      state.query = '';
      searchInput.value = '';
      applyFilter();
      searchInput.focus();
    },
    { small: true, title: '清空搜索，恢复全部分组' }
  );
  const searchCount = h('span', { class: 'settings-search-count', text: '' });
  searchBar.append(searchInput, clearBtn, searchCount);
  const scrollHost = h('div', { class: 'scroll-host', id: 'settings-scroll' });
  const body = h('div', { id: 'settings-body' });
  scrollHost.appendChild(body);
  root.appendChild(toolbar);
  root.appendChild(searchBar);
  root.appendChild(scrollHost);
  container.appendChild(root);
  state.host = root;
  state.scrollHost = scrollHost;
  state.body = body;
  state.searchInput = searchInput;
  state.clearBtn = clearBtn;
  state.searchCount = searchCount;

  scrollHost.addEventListener('scroll', () => store.setScroll('settings', scrollHost.scrollTop));
  render();
  requestAnimationFrame(() => {
    scrollHost.scrollTop = store.scrollOf('settings', 0);
  });
  return { render };
}

function draft() {
  const st = store.get();
  if (!state.draft) state.draft = structuredCloneSafe(st.settings);
  return state.draft;
}

function structuredCloneSafe(o) {
  try {
    return JSON.parse(JSON.stringify(o));
  } catch (err) {
    return o;
  }
}

// 某个平台「到底有没有可用 Key」。
// 除了自己的 Key，还要算上 reuseAiKey（DeepSeek 搜索复用 AI 平台 Key）——
// 否则下拉框会显示「未配 Key」，但实际请求是能跑的。
function platformKeyState(p, d) {
  const saved = !!(p && (p.apiKeySet || p.apiKey));
  const typed = !!(p && p.apiKey && !String(p.apiKey).includes('•'));
  let reused = false;
  if (p && p.reuseAiKey) {
    const ai = ((d && d.ai && d.ai.platforms) || []).find((x) => x.id === p.reuseAiKey);
    reused = !!(ai && (ai.apiKeySet || ai.apiKey));
  }
  return { own: saved || typed, reused, configured: saved || typed || reused };
}

function markDirty() {
  state.dirty = true;
  renderToolbar();
}

export function render() {
  const st = store.get();
  if (!state.body || !st.settings) return;
  renderToolbar();
  const scroll = state.scrollHost ? state.scrollHost.scrollTop : 0;
  clear(state.body);
  // 没有未保存改动时，外部设置变化（例如顶栏切主题、另一个面板保存）要反映到草稿；
  // 有改动时保留草稿，避免把用户正在编辑的内容冲掉。
  if (!state.dirty) state.draft = structuredCloneSafe(st.settings);
  const d = draft();

  // ---- 常驻提示：为什么现在不能用（第七章）----
  const issues = (st.readiness && st.readiness.issues) || [];
  if (issues.length) {
    const box = h('div', { class: 'group' });
    const inner = h('div', { class: 'group-body', style: { background: 'var(--warn-soft)' } });
    inner.appendChild(h('div', { class: 'section-title', text: '配置状态' }));
    for (const i of issues) {
      const row = h('div', {
        class: `alert ${i.level === 'error' ? 'error' : i.level === 'warn' ? 'warn' : 'info'}`,
        style: { marginBottom: '4px' }
      });
      row.appendChild(h('div', { text: i.text }));
      const target = AREA_GROUP[i.area];
      if (target) {
        row.appendChild(
          h('span', {
            class: 'alert-action',
            text: '去配置 ›',
            onclick: () => jumpToGroup(target)
          })
        );
      }
      inner.appendChild(row);
    }
    inner.appendChild(
      h('span', {
        class: 'alert-action',
        text: '打开首次向导 ›',
        onclick: () => app.panels.wizard && app.panels.wizard.open()
      })
    );
    box.appendChild(inner);
    state.body.appendChild(box);
  }

  state.body.appendChild(generalGroup(d));
  state.body.appendChild(aiGroup(d));
  state.body.appendChild(asrGroup(d));
  state.body.appendChild(promptGroup(d));
  state.body.appendChild(rulesGroup(d));
  state.body.appendChild(glossaryGroup(d));
  state.body.appendChild(searchGroup(d));
  state.body.appendChild(mcpGroup(d));
  state.body.appendChild(skillsGroup(d));
  state.body.appendChild(exportGroup(d));
  state.body.appendChild(batchGroup(d));
  state.body.appendChild(historyGroup(d));
  state.body.appendChild(pageGroup(d));
  state.body.appendChild(advancedGroup(d));

  const noResult = h('div', {
    class: 'note settings-no-result',
    text: '没有匹配的设置项。试试「Key」「导出」「超时」「MCP」。'
  });
  state.body.appendChild(noResult);
  state.noResult = noResult;
  applyFilter();

  requestAnimationFrame(() => {
    if (state.scrollHost && Math.abs(state.scrollHost.scrollTop - scroll) > 4) {
      state.scrollHost.scrollTop = scroll;
    }
  });
}

function setGroupOpenEl(g, open) {
  if (!g) return;
  const head = g.querySelector('.group-head');
  const body = g.querySelector('.group-body');
  if (head) head.dataset.open = open ? 'true' : 'false';
  if (body) {
    body.dataset.open = open ? 'true' : 'false';
    body.style.display = open ? 'block' : 'none';
  }
}

function captureGroupOpen() {
  const map = new Map();
  for (const g of state.body.querySelectorAll('[data-group-key]')) {
    const head = g.querySelector('.group-head');
    map.set(g.dataset.groupKey, head && head.dataset.open === 'true');
  }
  return map;
}

// 搜索只过滤视图：不删分组、不改配置。
function applyFilter() {
  if (!state.body) return;
  const q = String(state.query || '').trim().toLowerCase();
  const groups = Array.from(state.body.querySelectorAll('[data-group-key]'));
  if (q && !state.preSearchOpen) state.preSearchOpen = captureGroupOpen();
  let shown = 0;
  for (const g of groups) {
    const hay = `${g.dataset.search || ''} ${g.textContent || ''}`.toLowerCase();
    const ok = !q || hay.includes(q);
    g.style.display = ok ? '' : 'none';
    if (ok) {
      shown += 1;
      if (q) setGroupOpenEl(g, true);
    }
  }
  // 清空搜索时恢复搜索前的展开状态
  if (!q && state.preSearchOpen) {
    for (const [key, open] of state.preSearchOpen) {
      setGroupOpenEl(state.body.querySelector(`[data-group-key="${key}"]`), open);
    }
    state.preSearchOpen = null;
  }
  if (state.noResult) state.noResult.style.display = q && !shown ? 'block' : 'none';
  if (state.clearBtn) state.clearBtn.disabled = !q;
  if (state.searchCount) {
    state.searchCount.textContent = q ? `${shown}/${groups.length} 组` : `${groups.length} 个分组`;
  }
}

// 「去配置」：清空搜索、展开目标分组并滚动过去，优先聚焦 Key 输入框。
function jumpToGroup(key) {
  if (!state.body) return;
  if (state.query) {
    state.query = '';
    if (state.searchInput) state.searchInput.value = '';
  }
  applyFilter();
  const g = state.body.querySelector(`[data-group-key="${key}"]`);
  if (!g) return;
  setGroupOpenEl(g, true);
  store.setGroupOpen(key, true);
  if (typeof g.scrollIntoView === 'function') g.scrollIntoView({ block: 'start', behavior: 'smooth' });
  const focusable = g.querySelector(
    'input[type="password"], input[placeholder*="Key"], input[placeholder*="key"], select, textarea, input.input'
  );
  if (focusable) setTimeout(() => focusable.focus({ preventScroll: true }), 260);
}

function renderToolbar() {
  const bar = state.host.querySelector('.pane-toolbar');
  if (!bar) return;
  clear(bar);
  bar.appendChild(
    button(state.dirty ? '保存设置 *' : '保存设置', () => save(), { small: true, primary: true, title: '显式保存（自动保存之外的明确确认）' })
  );
  bar.appendChild(button('放弃改动', () => reload(), { small: true, disabled: !state.dirty }));
  bar.appendChild(button('重置为默认', () => resetAll(), { small: true, danger: true }));
  bar.appendChild(button('诊断', () => diagnosticsDialog(), { small: true }));
  bar.appendChild(button('首次向导', () => app.panels.wizard && app.panels.wizard.open(), { small: true, title: '重新打开首次使用向导（随时可跳过）' }));
  bar.appendChild(h('span', { class: 'spacer' }));
  bar.appendChild(h('span', { class: 'muted', text: state.dirty ? '有未保存的改动' : '已保存' }));
}

// ---------------------------------------------------------------------------
// 分组
// ---------------------------------------------------------------------------

const META_BY_KEY = {
  general: metaGeneral,
  ai: (d) => metaPlatform(d, 'ai'),
  asr: (d) => metaPlatform(d, 'asr'),
  search: metaSearch,
  export: metaExport,
  rules: metaRules,
  glossary: metaGlossary,
  mcp: metaMcp,
  skills: metaSkills,
  prompt: metaPrompt
};

function groupWrap(key, title, openDefault, bodyFn, meta, keywords) {
  const resolvedMeta = meta != null ? meta : META_BY_KEY[key] ? META_BY_KEY[key](draft()) : '';
  const g = collapsible(title, openDefault, bodyFn, {
    stateKey: key,
    meta: resolvedMeta,
    isOpen: (k, def) => store.groupOpen(k, def),
    onToggle: (k, open) => store.setGroupOpen(k, open)
  });
  // 搜索只依赖 data 属性，不拆 DOM 结构
  g.dataset.groupKey = key;
  g.dataset.search = [key, title, resolvedMeta, keywords].filter(Boolean).join(' ');
  return g;
}

function activePlatformOf(d, group) {
  const cfg = (d && d[group]) || {};
  const list = Array.isArray(cfg.platforms) ? cfg.platforms : [];
  return list.find((p) => p.id === cfg.activeId) || list[0] || null;
}

function metaPlatform(d, group) {
  const p = activePlatformOf(d, group);
  if (!p) return '未选择平台';
  const ks = platformKeyState(p, d);
  const model = p.model ? ` · ${p.model}` : '';
  return `${p.name || p.id} · ${ks.configured ? 'Key 已配' : 'Key 未配'}${model}`.slice(0, 64);
}

function metaGeneral(d) {
  const g = (d && d.general) || {};
  const theme = { system: '跟随系统', light: '浅色', dark: '深色' }[g.theme] || '跟随系统';
  const layout = { one: '单列', two: '双列', auto: '自动' }[g.layout] || '单列';
  return `${theme} · ${layout} · ${Math.round((Number(g.fontScale) || 1) * 100)}%`;
}

function metaSearch(d) {
  const s = (d && d.search) || {};
  const list = Array.isArray(s.platforms) ? s.platforms : [];
  const p = list.find((x) => x.id === s.activeId) || list[0] || null;
  const parts = [];
  if (p) {
    const ks = platformKeyState(p, d);
    parts.push(p.name || p.id, ks.configured ? 'Key 已配' : 'Key 未配');
  } else {
    parts.push('未配置平台');
  }
  if (s.keylessFallback !== false) parts.push('免费引擎兜底');
  return parts.join(' · ').slice(0, 64);
}

function metaExport(d) {
  const c = (d && d.exportCfg) || {};
  const f = EXPORT_FORMATS.find((x) => x.id === c.format);
  const t = EXPORT_TEMPLATES.find((x) => x.id === c.template);
  return `${f ? f.label : String(c.format || 'SRT').toUpperCase()} · ${t ? t.label : c.template || '默认'}`.slice(0, 64);
}

function metaRules(d) {
  const o = (d && d.optimize) || {};
  const groups = Array.isArray(o.groups) ? o.groups : [];
  const active = groups.find((g) => g.id === o.activeGroupId) || groups[0];
  return `${groups.length} 组${active ? ` · 当前 ${active.name || '未命名'}` : ''}`.slice(0, 64);
}

function metaGlossary(d) {
  const list = (d && d.optimize && d.optimize.glossary) || [];
  return `${list.length} 条术语`;
}

function metaMcp(d) {
  const m = (d && d.mcp) || {};
  const n = Array.isArray(m.servers) ? m.servers.length : 0;
  return `${m.enabled ? '已启用' : '未启用'}${n ? ` · ${n} 个服务` : ''}`;
}

function metaSkills(d) {
  const list = (d && d.skills && d.skills.items) || [];
  return `${list.length} 个技能`;
}

function metaPrompt(d) {
  const p = (d && d.prompt) || {};
  return p.system === DEFAULT_SYSTEM_PROMPT ? '默认提示词' : '已自定义';
}

// ---------------------------------------------------------------------------
// MCP 服务（给模型装上「手和脚」）
// ---------------------------------------------------------------------------

function mcpGroup(d) {
  return groupWrap('mcp', 'MCP 服务（给模型装上工具）', false, (body) => {
    d.mcp = d.mcp || { enabled: false, servers: [], callTimeoutMs: 60000, maxToolRounds: 6 };
    d.mcp.servers = d.mcp.servers || [];
    body.appendChild(
      checkbox(d.mcp.enabled, (v) => { d.mcp.enabled = v; markDirty(); }, '启用 MCP（对话时把工具交给模型，模型可自行调用）')
    );
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          'MCP = Model Context Protocol。浏览器扩展无法启动本地进程，因此只支持远程传输：\n' +
          '· http —— 直接 POST JSON-RPC 的 MCP 端点\n' +
          '· sse  —— 先建立事件流、再按服务端给出的 endpoint 发请求\n' +
          '（不支持 stdio。）'
      })
    );

    const list = h('div', { class: 'platform-list' });
    d.mcp.servers.forEach((sv, i) => {
      const card = h('div', { class: 'platform-card' });
      const head = h('div', { class: 'platform-head' });
      head.appendChild(h('span', { class: 'platform-name', text: sv.name || `服务 ${i + 1}` }));
      head.appendChild(h('span', { class: 'spacer' }));
      head.appendChild(
        button('测试连接', async () => {
          try {
            const out = await call('mcp.probe', { server: sv }, { timeoutMs: 60000 });
            const names = (out.tools || []).map((t) => t.name).join('、') || '（该服务没有暴露工具）';
            toast({ title: `连接成功：${(out.tools || []).length} 个工具`, detail: `${out.serverInfo ? out.serverInfo.name || '' : ''} ${names}` }, 'ok', 6000);
          } catch (err) {
            showError(err, 'MCP 连接失败');
          }
        }, { small: true, primary: true })
      );
      head.appendChild(
        button('删除', () => {
          d.mcp.servers.splice(i, 1);
          markDirty();
          render();
        }, { small: true, danger: true })
      );
      card.appendChild(head);
      const cb = h('div', { class: 'platform-body' });
      cb.appendChild(
        field('名称', textInput(sv.name || '', (v) => { sv.name = v; markDirty(); }, { placeholder: '例如 高德地图' }))
      );
      cb.appendChild(
        field('传输方式', select(sv.transport || 'http', [
          { value: 'http', label: 'HTTP（POST JSON-RPC）' },
          { value: 'sse', label: 'SSE（事件流）' }
        ], (v) => { sv.transport = v; markDirty(); }))
      );
      cb.appendChild(
        field('服务地址', textInput(sv.url || '', (v) => { sv.url = v; markDirty(); }, { placeholder: 'https://example.com/mcp' }))
      );
      cb.appendChild(
        field('鉴权 Token（可选）', textInput(sv.token || '', (v) => { sv.token = v; markDirty(); }, { placeholder: '留空则不发送 Authorization', password: true }))
      );
      cb.appendChild(
        checkbox(sv.enabled !== false, (v) => { sv.enabled = v; markDirty(); }, '启用该服务')
      );
      card.appendChild(cb);
      list.appendChild(card);
    });
    body.appendChild(field('服务列表', list));
    body.appendChild(
      button('添加 MCP 服务', () => {
        d.mcp.servers.push({
          id: `mcp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
          name: '',
          transport: 'http',
          url: '',
          token: '',
          enabled: true,
          headers: {}
        });
        markDirty();
        render();
      }, { small: true })
    );
    body.appendChild(
      field('单次工具调用超时（秒）', numberInput(Math.round((d.mcp.callTimeoutMs || 60000) / 1000), (v) => {
        d.mcp.callTimeoutMs = Math.max(5, Math.min(300, v)) * 1000;
        markDirty();
      }, { min: 5, max: 300 }))
    );
    body.appendChild(
      field('最多工具轮数', numberInput(d.mcp.maxToolRounds || 6, (v) => {
        d.mcp.maxToolRounds = Math.max(1, Math.min(12, v));
        markDirty();
      }, { min: 1, max: 12 }))
    );
    body.appendChild(
      h('div', { class: 'note', text: '并非所有平台都支持函数调用。若模型不返回工具调用，MCP 会静默不生效（不会影响普通对话）。' })
    );
  });
}

// ---------------------------------------------------------------------------
// Skills（可复用的提示词 / 工作流）
// ---------------------------------------------------------------------------

function skillsGroup(d) {
  return groupWrap('skills', 'Skills（可复用的提问模板）', false, (body) => {
    d.skills = d.skills || { enabled: true, items: [] };
    d.skills.items = d.skills.items || [];
    body.appendChild(
      checkbox(d.skills.enabled, (v) => { d.skills.enabled = v; markDirty(); }, '启用 Skills（对话区出现 ✨ 图标）')
    );
    const list = h('div', { class: 'platform-list' });
    d.skills.items.forEach((sk, i) => {
      const card = h('div', { class: 'platform-card' });
      const head = h('div', { class: 'platform-head' });
      head.appendChild(h('span', { class: 'platform-name', text: `${sk.icon || '✨'} ${sk.name || '未命名'}` }));
      head.appendChild(h('span', { class: 'spacer' }));
      if (sk.source === 'builtin') head.appendChild(h('span', { class: 'muted', text: '内置' }));
      head.appendChild(
        button('删除', () => {
          d.skills.items.splice(i, 1);
          markDirty();
          render();
        }, { small: true, danger: true })
      );
      card.appendChild(head);
      const cb = h('div', { class: 'platform-body' });
      cb.appendChild(field('图标', textInput(sk.icon || '', (v) => { sk.icon = v; markDirty(); }, { placeholder: '✨' })));
      cb.appendChild(field('名称', textInput(sk.name || '', (v) => { sk.name = v; markDirty(); })));
      cb.appendChild(field('说明', textInput(sk.desc || '', (v) => { sk.desc = v; markDirty(); }, { placeholder: '一句话说明用途' })));
      const ta = h('textarea', {
        class: 'input',
        style: { minHeight: '80px', width: '100%' },
        value: sk.body || '',
        placeholder: '技能正文：会作为指令追加到你的提问里',
        oninput: (e) => { sk.body = e.target.value; markDirty(); }
      });
      cb.appendChild(field('技能正文', ta));
      card.appendChild(cb);
      list.appendChild(card);
    });
    body.appendChild(field('技能列表', list));
    body.appendChild(
      button('添加技能', () => {
        d.skills.items.push({
          id: `skill_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
          icon: '✨',
          name: '',
          desc: '',
          body: '',
          source: 'user'
        });
        markDirty();
        render();
      }, { small: true })
    );
    body.appendChild(h('div', { class: 'note', text: '对话区点 ✨ 选择技能，会把技能正文与你的提问一起发给 AI。' }));

    // ---- 导入 SKILL.md（Cherry Studio / Anthropic Skills 约定）----
    const fileInput = h('input', { type: 'file', accept: '.md,.markdown,text/markdown', multiple: true, style: { display: 'none' } });
    fileInput.addEventListener('change', async () => {
      const files = Array.from(fileInput.files || []);
      fileInput.value = '';
      if (!files.length) return;
      let added = 0;
      const blocked = [];
      for (const f of files) {
        try {
          const text = await f.text();
          const sk = SKILLS.skillFromMarkdown(text, { folderName: f.name.replace(/\.md$/i, ''), icon: '📄' });
          d.skills.items.push(sk);
          added += 1;
          if (sk.execDeps) blocked.push(`${sk.name}（用到：${sk.execDeps.join('、')}）`);
        } catch (err) {
          toast({ title: `导入失败：${f.name}`, detail: (err && err.message) || '' }, 'warn', 4000);
        }
      }
      if (added) {
        markDirty();
        render();
        toast(
          {
            title: `已导入 ${added} 个技能`,
            detail: blocked.length
              ? `以下技能声明了本地执行依赖，浏览器扩展无法运行，只会作为指令使用：${blocked.join('；')}`
              : '技能正文会作为指令交给模型'
          },
          blocked.length ? 'warn' : 'ok',
          blocked.length ? 8000 : 3000
        );
      }
    });
    body.appendChild(fileInput);
    body.appendChild(
      button('导入 SKILL.md', () => fileInput.click(), { small: true })
    );
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '兼容 Cherry Studio / Anthropic 的 SKILL.md 格式（YAML frontmatter + Markdown 正文）：\n' +
          'name / description 会成为技能名称与说明，正文作为指令。\n' +
          '⚠ 浏览器扩展无法执行技能里的 shell / python 脚本，这类技能只会当提示词用。'
      })
    );
  });
}

function generalGroup(d) {
  return groupWrap('general', '通用（主题 / 字号 / 布局）', true, (body) => {
    body.appendChild(
      field(
        '主题',
        select(d.general.theme, [
          { value: 'system', label: '跟随系统' },
          { value: 'light', label: '浅色' },
          { value: 'dark', label: '深色' }
        ], (v) => {
          d.general.theme = v;
          markDirty();
        })
      )
    );
    const fontRow = h('div', { class: 'row tight' });
    fontRow.appendChild(
      h('input', {
        class: 'input',
        type: 'range',
        min: '0.8',
        max: '1.6',
        step: '0.05',
        value: String(d.general.fontScale),
        style: { flex: '1 1 auto' },
        oninput: (e) => {
          d.general.fontScale = Number(e.target.value);
          document.documentElement.style.setProperty('--fs', `${(13 * d.general.fontScale).toFixed(1)}px`);
        },
        onchange: markDirty
      })
    );
    fontRow.appendChild(h('span', { class: 'mono', text: `${Math.round(d.general.fontScale * 100)}%` }));
    body.appendChild(field('字号缩放', fontRow));
    body.appendChild(
      field(
        '布局',
        select(d.general.layout, [
          { value: 'one', label: '单列堆叠（默认，推荐窄侧边栏）' },
          { value: 'two', label: '双列（左字幕 / 右总结·AI）' },
          { value: 'auto', label: '自动（宽度 <420px 才单列）' }
        ], (v) => {
          d.general.layout = v;
          markDirty();
        })
      )
    );
    body.appendChild(checkbox(d.general.autoFollow, (v) => { d.general.autoFollow = v; markDirty(); }, '字幕自动高亮并滚动到当前句（跟随播放）'));
    body.appendChild(checkbox(d.diagnostics.verbose, (v) => { d.diagnostics.verbose = v; markDirty(); }, '输出详细日志（排查问题时开启）'));
  });
}


function aiGroup(d) {
  return groupWrap('ai', 'AI 平台（默认 DeepSeek）', true, (body) => {
    body.appendChild(
      h('div', { class: 'note', text: '所有 AI 平台都是同一套 OpenAI 兼容配置：接口地址 + 模型 + API Key。用下拉框选平台，只显示当前这一家的配置，不用来回翻。' })
    );
    body.appendChild(platformPicker('ai', d));
    body.appendChild(
      field('温度（0~2）', numberInput(d.ai.temperature, (v) => { d.ai.temperature = Math.max(0, Math.min(2, v)); markDirty(); }, { min: 0, max: 2, step: 0.1 }))
    );
    body.appendChild(
      field(
        '最大输出 token',
        numberInput(d.ai.maxTokens, (v) => { d.ai.maxTokens = Math.max(256, Math.min(64000, Number(v) || 8192)); markDirty(); }, { min: 256, max: 64000, step: 512 })
      )
    );
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '说明：这个值决定 AI **一次最多输出多少字**（约 1 token ≈ 0.6~1 个汉字）。\n' +
          '· 想要更长、更详细的总结就调大（8192 约能写 5000~8000 字）。\n' +
          '· 上限由**模型本身**决定，不是每个模型都支持 64000；' +
          '超出模型能力时服务端会直接报错，按平台文档调即可。\n' +
          '· 调大后单次费用会相应增加。'
      })
    );
    body.appendChild(
      checkbox(
        d.ai.expandReasoning === true,
        (v) => { d.ai.expandReasoning = v; markDirty(); },
        '思维链默认展开（推理模型如 deepseek-reasoner 会返回思考过程）'
      )
    );
    body.appendChild(
      checkbox(
        d.ai.sendOnEnter !== false,
        (v) => { d.ai.sendOnEnter = v; markDirty(); },
        '回车发送消息（Shift + 回车换行；关闭后改为 Ctrl / Cmd + 回车发送）'
      )
    );
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '思维链与最终回答是**分开显示**的：回答上方会有一个可折叠的「💭 思考过程」块。\n' +
          '默认折叠 —— 思考过程动辄上千字，展开会把回答挤出屏幕。\n' +
          '折叠时会显示一行滚动的思考摘要，鼠标点标题即可展开全文。'
      })
    );
  });
}

function asrGroup(d) {
  return groupWrap('asr', '语音识别平台（默认 硅基流动）', true, (body) => {
    body.appendChild(
      h('div', { class: 'note', text: '语音识别平台统一走 OpenAI 兼容的 /audio/transcriptions：接口地址 + 模型 + Key，请求方式（base64 JSON / multipart）与文件字段名因平台而异。' })
    );
    body.appendChild(platformPicker('asr', d));
    const grid = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px' } });
    grid.appendChild(field('并发切片数', numberInput(d.asr.concurrency, (v) => { d.asr.concurrency = Math.max(1, Math.min(8, v)); markDirty(); }, { min: 1, max: 8 })));
    grid.appendChild(field('单片超时（秒）', numberInput(d.asr.timeoutSeconds, (v) => { d.asr.timeoutSeconds = Math.max(30, v); markDirty(); }, { min: 30, max: 1800, step: 30 })));
    grid.appendChild(field('平台单文件上限（MB）', numberInput(d.asr.sizeLimitMB, (v) => { d.asr.sizeLimitMB = Math.max(1, v); markDirty(); }, { min: 1, max: 1024 })));
    grid.appendChild(field('切片时长（秒）', numberInput(d.asr.sliceSeconds, (v) => { d.asr.sliceSeconds = Math.max(45, Math.min(600, v)); markDirty(); }, { min: 45, max: 600, step: 15 })));
    grid.appendChild(field('切片重叠（秒）', numberInput(d.asr.overlapSeconds, (v) => { d.asr.overlapSeconds = Math.max(0, Math.min(30, v)); markDirty(); }, { min: 0, max: 30, step: 0.5 })));
    body.appendChild(grid);
    body.appendChild(checkbox(d.asr.autoOptimizeAfter, (v) => { d.asr.autoOptimizeAfter = v; markDirty(); }, '转录完成后自动做 AI 优化（默认关闭，会消耗额度）'));
    body.appendChild(checkbox(d.asr.autoApplyAfter, (v) => { d.asr.autoApplyAfter = v; markDirty(); }, '转录完成后自动替换（默认关闭）'));

    body.appendChild(h('div', { class: 'note', text: '说明：分片时长会按「平台单文件上限」自动收缩；若某片仍超限，会按 0.7 系数重切，最多 3 次。终止后不会再继续消耗额度。' }));
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '提速建议：\n' +
          '· 「并发切片数」提高到 4~8 —— 分片互相独立，提速近乎线性；\n' +
          '  设成 1 等于完全串行，是最常见的“慢”的原因。\n' +
          '· 「切片时长」调小到 120~300 秒 —— 分片更多、更快出结果，' +
          '不会卡在某一长片上；代价是请求数变多。\n' +
          '· 若平台按 M4A 上传（如硅基流动），扩展会**并行**做实时编码，' +
          '只在开头等第一片；换成原生支持 WAV 的模型可完全省掉这段编码。'
      })
    );
  });
}

// ---------------------------------------------------------------------------
// 平台选择：下拉框 + 只显示当前平台的配置
// ---------------------------------------------------------------------------

const PLATFORM_META = {
  ai: {
    listKey: 'ai',
    label: 'AI 平台',
    newIdPrefix: 'custom_ai_',
    newName: '新 AI 平台',
    template: { homepage: '', keyUrl: '', baseUrl: 'https://', model: '', apiKey: '', models: [] }
  },
  asr: {
    listKey: 'asr',
    label: '语音识别平台',
    newIdPrefix: 'custom_asr_',
    newName: '新语音平台',
    template: { homepage: '', keyUrl: '', baseUrl: 'https://', model: '', transport: 'multipart', keyField: 'file', apiKey: '', models: [] }
  },
  search: {
    listKey: 'search',
    label: '检索服务商',
    newIdPrefix: 'search_',
    newName: '新检索服务商',
    template: { homepage: '', keyUrl: '', baseUrl: 'https://', apiKey: '', kind: 'tavily', models: [] }
  }
};

function platformPicker(kind, d) {
  const meta = PLATFORM_META[kind];
  const list = d[meta.listKey].platforms || [];
  const wrap = h('div');

  // 当前编辑哪个：优先用户在这个分组里选过的，否则用「使用中」的平台
  const editKey = `editPlatform_${kind}`;
  let editingId = store.get().ui[editKey];
  if (!editingId || !list.some((p) => p.id === editingId)) {
    editingId = d[meta.listKey].activeId || (list[0] && list[0].id);
  }
  const current = list.find((p) => p.id === editingId) || list[0] || null;

  const options = list.map((p) => ({
    value: p.id,
    label: `${p.name || p.id}${p.id === d[meta.listKey].activeId ? '（使用中）' : ''}${platformKeyState(p, d).configured ? '' : ' · 未配 Key'}`
  }));

  const isCustomNew = editingId && String(editingId).startsWith(meta.newIdPrefix);
  if (isCustomNew) options.push({ value: editingId, label: `${meta.newName}（新）` });
  options.push({ value: '__add__', label: '➕ 添加自定义平台…' });

  const row = h('div', { class: 'row tight' });
  row.appendChild(
    h('span', { class: 'row-label', text: `选择${meta.label}` })
  );
  row.appendChild(
    select(
      editingId,
      options,
      (v) => {
        if (v === '__add__') {
          const id = `${meta.newIdPrefix}${Date.now().toString(36)}`;
          d[meta.listKey].platforms.push({ id, name: meta.newName, ...meta.template });
          store.setUi({ [editKey]: id });
          markDirty();
          render();
          return;
        }
        store.setUi({ [editKey]: v });
        render();
      }
    )
  );
  if (current && current.id !== d[meta.listKey].activeId) {
    row.appendChild(
      button('设为使用中', () => {
        d[meta.listKey].activeId = current.id;
        markDirty();
        render();
      }, { small: true, primary: true, title: '把这一家设为当前使用的平台' })
    );
  }
  if (current && current.id === d[meta.listKey].activeId) {
    row.appendChild(h('span', { class: 'pill pill-brand', text: '当前使用中' }));
  }
  wrap.appendChild(field(`${meta.label}`, row, `共 ${list.length} 家可选；下拉框只显示选中这一家的配置。`));

  if (current) {
    wrap.appendChild(platformDetail(kind, list, current, d, () => render()));
  } else {
    wrap.appendChild(h('div', { class: 'note', text: '还没有任何平台，请从下拉框选择「➕ 添加自定义平台…」。' }));
  }
  return wrap;
}

// 单个平台的配置详情（关键字段 + 折叠的高级项）
function platformDetail(kind, list, p, d, rerender) {
  const card = h('div', { class: 'platform-card' });
  const head = h('div', { class: 'platform-head' });
  head.appendChild(h('span', { class: 'platform-name', text: p.name || p.id }));
  head.appendChild(h('span', { class: 'spacer' }));
  if (p.keyUrl) {
    head.appendChild(h('a', { class: 'btn btn-sm', href: p.keyUrl, target: '_blank', rel: 'noreferrer', text: '申请 Key', title: `打开 ${p.keyUrl}` }));
  }
  if (p.homepage) {
    head.appendChild(h('a', { class: 'btn btn-sm', href: p.homepage, target: '_blank', rel: 'noreferrer', text: '官网' }));
  }
  head.appendChild(
    button('删除', () => {
      confirmDialog('删除平台', `确定删除「${p.name}」？`, () => {
        const arr = list.filter((x) => x.id !== p.id);
        d[kind].platforms = arr;
        if (d[kind].activeId === p.id) d[kind].activeId = (arr[0] || {}).id || '';
        store.setUi({ [`editPlatform_${kind}`]: d[kind].activeId });
        markDirty();
        rerender();
      });
    }, { small: true, danger: true, disabled: list.length <= 1 })
  );
  card.appendChild(head);

  const body = h('div', { class: 'platform-body' });
  body.appendChild(field('名称', textInput(p.name, (v) => { p.name = v; markDirty(); })));

  // 接口地址：硅基流动这类有国内/国际双站点的服务，给一个一键切换，
  // 避免手改字符串出错（站点与 Key 不匹配时的表现是 401，很难自查）。
  const baseRow = h('div', { class: 'row tight' });
  const baseInput = textInput(p.baseUrl, (v) => { p.baseUrl = v; markDirty(); }, { placeholder: 'https://api.example.com/v1' });
  baseInput.style.flex = '1 1 auto';
  baseRow.appendChild(baseInput);
  const altHosts = alternateHostsForUi(p.baseUrl);
  if (altHosts.length) {
    baseRow.appendChild(
      button(`改用 ${altHosts[0].host}`, () => {
        p.baseUrl = altHosts[0].url;
        markDirty();
        render();
      }, { small: true, title: `${p.baseUrl} → ${altHosts[0].url}（切到另一个站点）` })
    );
  }
  const baseNote = (() => {
    const host = hostOf(p.baseUrl);
    if (!host) return '填写接口地址后，如提示缺少域名权限，点「申请域名权限」。';
    if (/api\.siliconflow\.cn$/i.test(host)) {
      return '当前是国内站。**必须使用 cloud.siliconflow.cn 申请的 Key**；国际站的 Key 在这里会 401。';
    }
    if (/api\.siliconflow\.com$/i.test(host)) {
      return '当前是国际站。**必须使用 cloud.siliconflow.com 申请的 Key**；国内站的 Key 在这里会 401。';
    }
    return '如提示缺少域名权限（自定义接口地址常见），点「申请域名权限」。';
  })();
  body.appendChild(field('接口地址（Base URL）', baseRow, baseNote));
  if (kind !== 'search') {
    const modelRow = h('div', { class: 'row tight' });
    const modelInput = textInput(p.model, (v) => { p.model = v; markDirty(); });
    modelInput.style.flex = '1 1 auto';
    modelRow.appendChild(modelInput);
    modelRow.appendChild(
      button('选择模型', () => {
        const models = state.modelCache[p.id] || p.models || [];
        if (!models.length) {
          toast({ title: '还没有模型列表', detail: '先点「探测模型」拉一次，或直接在输入框里填模型名。' }, 'warn', 4000);
          return;
        }
        openOverlay(
          `为「${p.name}」选择模型`,
          h(
            'div',
            { class: 'row tight' },
            models.map((m) =>
              h('span', {
                class: 'tag',
                text: m,
                dataset: { active: String(p.model === m) },
                onclick: () => {
                  p.model = m;
                  markDirty();
                  closeOverlays();
                  rerender();
                }
              })
            )
          ),
          [{ label: '关闭', onClick: () => closeOverlays() }],
          { width: '460px' }
        );
      }, { small: true })
    );
    modelRow.appendChild(
      button('核对模型', async () => {
        try {
          const res = await call('platform.models', { kind, id: p.id }, { timeoutMs: 40000 });
          state.modelCache[p.id] = res.models || [];
          const wanted = String(p.model || '').trim();
          const ok = (res.models || []).includes(wanted);
          // 把「打到了哪个地址、用的是多长的 Key」也报出来：
          // 这是区分「鉴权通过但没有该模型」和「地址/Key 配错」的关键信息。
          const where = res.url ? `· ${res.url}（Key 长度 ${res.keyLength}）` : '';
          if (res.fallback) {
            toast(
              {
                title: '没能从平台拉到模型列表',
                detail: `${res.reason || '请求失败'}${res.detail ? `：${String(res.detail).split('\n')[0]}` : ''}\n${where}\n下面显示的是内置建议，不代表平台真实可用模型。`
              },
              'warn',
              10000
            );
          } else if (ok) {
            toast(
              {
                title: `"${wanted}" 在该平台上可用`,
                detail: `共探测到 ${res.models.length} 个模型\n${where}\n注意：能列出 ≠ 能用于语音识别，仍需「测试连接」确认。`
              },
              'ok',
              8000
            );
          } else {
            const speech = (res.models || []).filter((m) => /audio|asr|whisper|sensevoice|speech|voice|gsr/i.test(m));
            toast(
              {
                title: `"${wanted}" 不在该平台的模型列表里`,
                detail: `${speech.length ? `可用的语音识别模型：${speech.slice(0, 6).join('、')}` : `平台模型（前 20）：${(res.models || []).slice(0, 20).join('、')}`}\n${where}`
              },
              'warn',
              9000
            );
          }
          rerender();
        } catch (err) {
          showError(err, '核对模型失败');
        }
      }, { small: true, title: '向平台拉一次模型列表，确认当前模型名确实存在' })
    );
    body.appendChild(
      field('模型', modelRow, '模型名必须属于这个平台。点「核对模型」可以直接确认；点「选择模型」从平台返回的列表里挑。')
    );
  }

  // 密钥：密码框 + 显示/隐藏 + 掩码提示
  const keyRow = h('div', { class: 'row tight' });
  const ks = platformKeyState(p, d);
  const visible = !!(store.get().ui.pendingKeyVisibility || {})[p.id];
  const typedKey = p.apiKey && !String(p.apiKey).includes('•') ? p.apiKey : '';
  const keyInput = h('input', {
    class: 'input',
    type: visible ? 'text' : 'password',
    // 已输入但还没保存的 Key 要留在输入框里：以前 value 恒为 ''，
    // 点一次「显示 / 隐藏」或其他重绘就会把刚粘贴的 Key 从界面上抹掉。
    value: typedKey,
    placeholder: ks.own
      ? `已保存：${p.apiKey || '••••'}（留空表示不改动）`
      : ks.reused
        ? '复用 AI 平台的 Key；这里留空即可'
        : '粘贴 API Key',
    style: { flex: '1 1 auto' },
    oninput: (e) => {
      p.apiKey = e.target.value;
      delete p.apiKeyClear;
      markDirty();
    }
  });
  keyRow.appendChild(keyInput);
  keyRow.appendChild(
    button(visible ? '隐藏' : '显示', () => {
      const ui = store.get().ui;
      store.setUi({ pendingKeyVisibility: { ...(ui.pendingKeyVisibility || {}), [p.id]: !visible } });
      rerender();
    }, { small: true })
  );
  if (ks.own) {
    keyRow.appendChild(
      button('清除', () => {
        p.apiKey = '';
        p.apiKeySet = false;
        // 空字符串在保存语义里等于「不改动」，必须用显式标记才能真正清掉
        p.apiKeyClear = true;
        markDirty();
        rerender();
      }, { small: true, danger: true })
    );
  }
  body.appendChild(
    field(
      'API Key',
      keyRow,
      `只保存在本机（不同步）。已保存的只显示掩码；留空保存表示「不改动」。当前：${
        ks.own ? '已配置' : ks.reused ? '已配置（复用 AI 平台 Key）' : '未配置'
      }`
    )
  );

  const acts = h('div', { class: 'row tight' });
  acts.appendChild(
    button('测试连接', async () => {
      const btn = acts.querySelector('button');
      btn.disabled = true;
      btn.textContent = '测试中…';
      try {
        await persistDraft({ silent: true });
        const res = await call('platform.test', { kind, id: p.id }, { timeoutMs: 60000 });
        toast({ title: `连接正常（${res.ms}ms）`, detail: res.sample || '' }, 'ok', 5000);
      } catch (err) {
        showError(err, '测试连接失败');
      } finally {
        btn.disabled = false;
        btn.textContent = '测试连接';
      }
    }, { small: true, primary: true })
  );
  acts.appendChild(
    button('探测模型', async () => {
      const btn = Array.from(acts.querySelectorAll('button')).find((b) => b.textContent === '探测模型');
      btn.disabled = true;
      btn.textContent = '探测中…';
      try {
        await persistDraft({ silent: true });
        const res = await call('platform.models', { kind, id: p.id }, { timeoutMs: 40000 });
        state.modelCache[p.id] = res.models || [];
        if (res.fallback) {
          toast({ title: '该平台没有模型列表接口', detail: `已给出常见模型建议${res.reason ? `（${res.reason}）` : ''}` }, 'warn', 5000);
        } else {
          toast({ title: `探测到 ${res.models.length} 个模型` }, 'ok');
        }
        rerender();
      } catch (err) {
        showError(err, '探测模型失败');
      } finally {
        btn.disabled = false;
        btn.textContent = '探测模型';
      }
    }, { small: true })
  );
  acts.appendChild(
    button('申请域名权限', async () => {
      try {
        const res = await call('permission.request', { url: p.baseUrl }, { timeoutMs: 120000 });
        toast({ title: `已授权 ${res.pattern}`, detail: res.already ? '此前已经授权过。' : '现在可以访问该域名。' }, 'ok');
      } catch (err) {
        showError(err, '申请域名权限失败');
      }
    }, { small: true, title: '自定义接口地址需要向浏览器申请该域名的访问权限' })
  );
  acts.appendChild(
    button('连通性诊断', async () => {
      const btn = Array.from(acts.querySelectorAll('button')).find((b) => b.textContent === '连通性诊断');
      btn.disabled = true;
      btn.textContent = '诊断中…';
      try {
        await persistDraft({ silent: true });
        const res = await call('platform.probe', { kind, id: p.id }, { timeoutMs: 120000 });
        const box = h('div');
        box.appendChild(
          h('div', {
            class: 'note',
            text: `Key：长度 ${res.keyLength}，末四位 ${res.keyTail}\n会依次测试每一个可能的地址与传输方式，下面是服务端的真实返回。`
          })
        );
        const table = h('div', { class: 'probe-table' });
        for (const row of res.rows || []) {
          const okMark = row.ok ? '✅' : row.status ? '❌' : '⚠';
          table.appendChild(
            h('div', { class: 'probe-row', dataset: { ok: String(!!row.ok) } }, [
              h('span', { class: 'probe-mark', text: okMark }),
              h('span', { class: 'probe-kind', text: `${row.kind} → ${row.url}` }),
              h('span', { class: 'probe-status', text: row.status == null ? '—' : String(row.status) }),
              h('span', { class: 'probe-note', text: row.note || '' })
            ])
          );
        }
        box.appendChild(table);
        const rows = res.rows || [];
        const modelsOk = rows.filter((r) => /models/.test(r.url) && r.ok);
        const asr500 = rows.filter((r) => /transcriptions|completions/.test(r.url) && r.status >= 500);
        const asr400 = rows.filter((r) => /transcriptions|completions/.test(r.url) && r.status === 400);
        const asr401 = rows.filter((r) => /transcriptions|completions/.test(r.url) && r.status === 401);
        const asrOk = rows.filter((r) => /transcriptions|completions/.test(r.url) && r.ok);
        let verdict;
        if (asrOk.length) {
          verdict = '✅ 有转录请求成功，Key、地址、模型都对。可以直接去「语音转录」。';
        } else if (asr500.length) {
          verdict =
            '⚠ 鉴权是通的（见 ✅ 行），转录请求也**送到了模型**，但服务端在转录这一步内部报错（5xx）。' +
            '这不是参数或权限问题，通常是**音频样本**的问题（静音/格式/时长）。请直接拿真实视频点「语音转录」验证；' +
            '如果真实音频也 5xx，那就是该平台这个模型当前不可用。';
        } else if (modelsOk.length && asr400.length) {
          verdict =
            '⚠ 鉴权是通的（/models 返回 200），但转录接口返回 400 —— **服务端在动模型之前就拒绝了请求**，' +
            '说明这个模型名不被转录接口接受。请把模型换成一个确定的语音识别模型（如 FunAudioLLM/SenseVoiceSmall）再试。';
        } else if (asr401.length && !modelsOk.length) {
          verdict = '⚠ 全部鉴权失败。这个 Key 在这些地址上都不被接受，请确认 Key 与「接口地址」属于同一个站。';
        } else {
          verdict = '请看上面每一行的状态码与响应体。';
        }
        box.appendChild(h('div', { class: 'note', text: verdict }));
        openOverlay('连通性诊断', box, [{ label: '关闭', onClick: () => closeOverlays() }], { width: '620px' });
      } catch (err) {
        showError(err, '连通性诊断失败');
      } finally {
        btn.disabled = false;
        btn.textContent = '连通性诊断';
      }
    }, { small: true, title: '逐个地址、逐个传输方式打一遍，把状态码列出来（不消耗额度）' })
  );
  body.appendChild(acts);

  // 可用模型标签
  //
  // 两种来源要分清（用户问「没点探测模型前为什么已经有可用模型」）：
  //   · state.modelCache[p.id] —— **点过「探测模型/选择模型」后**从平台
  //     `/v1/models` 拉回来的真实列表
  //   · p.models —— 内置的**种子列表**（预置的常见模型名），只是为了
  //     开箱即用，**不代表你的账号真的能用**
  // 之前两者混在一起、文案都写「可用模型」，容易让人以为已经验证过了。
  const probed = state.modelCache[p.id];
  const modelsRaw = (probed && probed.length ? probed : p.models) || [];
  // 把当前实际在用的模型并进去，避免「设置里显示的是别的模型」
  const models = modelsRaw.slice();
  if (p.model && !models.includes(p.model)) models.unshift(p.model);
  if (models.length) {
    const tags = h('div', { class: 'row tight model-tags' });
    for (const m of models) {
      tags.appendChild(
        h('span', {
          class: 'tag',
          text: m,
          dataset: { active: String(p.model === m) },
          title:
            p.model === m
              ? '当前使用的模型'
              : probed
                ? '平台返回的模型，点击切换'
                : '内置预设的模型名（未向平台核实，可能不可用）',
          onclick: () => {
            p.model = m;
            markDirty();
            rerender();
          }
        })
      );
    }
    body.appendChild(
      field(
        probed ? `模型（已核实 ${models.length} 个）` : `模型（内置预设 ${models.length} 个，未核实）`,
        tags
      )
    );
    if (!probed) {
      body.appendChild(
        h('div', {
          class: 'note',
          text:
            '这些是**内置预设**的模型名，方便开箱即用，但**不代表你的账号真的能用**。\n' +
            '点上面的「探测模型」会向平台拉取真实列表（需要已填 Key），拉回来后会替换成已核实的清单。'
        })
      );
    }
  }

  // 高级项：按平台差异收起，避免干扰
  const advanced = h('div');
  if (kind === 'asr') {
    advanced.appendChild(
      field(
        '请求方式',
        select(p.transport || 'multipart', [
          { value: 'multipart', label: 'multipart/form-data（OpenAI / Groq / 硅基流动）' },
          { value: 'base64-json', label: 'base64 JSON（{model, audio}）' },
          { value: 'chat-audio', label: '对话接口（/chat/completions + input_audio）' }
        ], (v) => { p.transport = v; markDirty(); })
      ),
      '不确定就保持 multipart：测试/转录失败时会自动按阶梯尝试其它两种传输方式。'
    );
    advanced.appendChild(field('音频字段名', textInput(p.keyField || 'file', (v) => { p.keyField = v; markDirty(); }), 'multipart 平台通常叫 file；base64 JSON 平台通常叫 audio。'));
    advanced.appendChild(
      field(
        '上传音频格式',
        select(p.audioFormat || 'auto', [
          { value: 'auto', label: '自动（按平台判断）' },
          { value: 'wav', label: 'WAV（16kHz 单声道）' },
          { value: 'm4a', label: 'M4A / MP4-AAC' }
        ], (v) => { p.audioFormat = v; markDirty(); })
      ),
      '硅基流动对 WAV 会返回 500（服务端解码失败），必须用 M4A。浏览器只能实时编码，' +
        '所以选 M4A 时耗时约等于音频时长。'
    );
    advanced.appendChild(
      field(
        '参数风格',
        select(p.paramStyle || 'auto', [
          { value: 'auto', label: '自动（按平台判断）' },
          { value: 'minimal', label: '最小参数：只发 file + model' },
          { value: 'full', label: '完整参数：带 response_format / language' }
        ], (v) => { p.paramStyle = v; markDirty(); })
      ),
      '硅基流动这类只认 file + model 的平台请选「最小参数」；想拿时间戳的 OpenAI 兼容平台选「完整参数」。'
    );
  }
  if (kind === 'search') {
    advanced.appendChild(
      field(
        '服务商类型',
        select(p.kind || 'tavily', [
          { value: 'tavily', label: 'Tavily' },
          { value: 'bocha', label: '博查 Bocha' },
          { value: 'serper', label: 'Serper（Google）' },
          { value: 'custom', label: '通用（?q= / Bearer）' }
        ], (v) => { p.kind = v; markDirty(); })
      )
    );
  }
  advanced.appendChild(field('官网地址', textInput(p.homepage, (v) => { p.homepage = v; markDirty(); }, { placeholder: 'https://' })));
  advanced.appendChild(field('申请 Key 链接', textInput(p.keyUrl, (v) => { p.keyUrl = v; markDirty(); }, { placeholder: 'https://' })));
  body.appendChild(
    collapsible('高级设置', false, (box) => box.appendChild(advanced), {
      stateKey: `platformAdvanced_${p.id}`,
      isOpen: (k, def) => store.groupOpen(k, def),
      onToggle: (k, open) => store.setGroupOpen(k, open)
    })
  );

  card.appendChild(body);
  return card;
}

function promptGroup(d) {
  return groupWrap('prompt', '提示词（可修改 + 多套模板）', false, (body) => {
    const st = store.get();
    const templates = d.prompt.templates || [];
    const active = templates.find((t) => t.id === d.prompt.activeId) || templates[0];
    const tags = h('div', { class: 'row tight' });
    for (const t of templates) {
      tags.appendChild(
        h('span', {
          class: 'tag',
          text: t.name,
          dataset: { active: String(t.id === (active && active.id)) },
          onclick: () => {
            d.prompt.activeId = t.id;
            markDirty();
            render();
          }
        })
      );
    }
    body.appendChild(field('提示词模板', tags));
    if (active) {
      const area = h('textarea', { class: 'input', style: { minHeight: '90px' } });
      area.value = active.text || '';
      area.addEventListener('input', () => {
        active.text = area.value;
        markDirty();
      });
      body.appendChild(field('当前模板内容', area, '默认提示词必须与需求文档一字不差：' + DEFAULT_SYSTEM_PROMPT));
      const row = h('div', { class: 'row tight' });
      row.appendChild(
        button('新建模板', () => {
          promptDialog('新建提示词模板', '我的模板', (name) => {
            d.prompt.templates.push({ id: `tpl_${Date.now().toString(36)}`, name: name || '未命名模板', text: '' });
            markDirty();
            render();
          });
        }, { small: true })
      );
      row.appendChild(
        button('重命名', () => {
          promptDialog('重命名模板', active.name, (name) => {
            active.name = name || active.name;
            markDirty();
            render();
          });
        }, { small: true })
      );
      row.appendChild(
        button('恢复默认文案', () => {
          active.text = DEFAULT_SYSTEM_PROMPT;
          markDirty();
          render();
        }, { small: true })
      );
      row.appendChild(
        button('删除模板', () => {
          d.prompt.templates = d.prompt.templates.filter((t) => t.id !== active.id);
          d.prompt.activeId = (d.prompt.templates[0] || {}).id || 'default';
          markDirty();
          render();
        }, { small: true, danger: true, disabled: active.id === 'default' })
      );
      body.appendChild(row);
    }
    body.appendChild(field('对话附加前缀', textInput(d.prompt.chatPrefix, (v) => { d.prompt.chatPrefix = v; markDirty(); }), '会加在系统提示词之后，用于约束「只依据字幕回答」。'));
  });
}

function rulesGroup(d) {
  return groupWrap('rules', '替换规则组（可保存 / 导出 / 导入 / 切换）', false, (body) => {
    const groups = d.optimize.groups || [];
    const active = groups.find((g) => g.id === d.optimize.activeGroupId) || groups[0];
    const tags = h('div', { class: 'row tight' });
    for (const g of groups) {
      tags.appendChild(
        h('span', {
          class: 'tag',
          text: g.name,
          dataset: { active: String(active && g.id === active.id) },
          onclick: () => {
            d.optimize.activeGroupId = g.id;
            markDirty();
            render();
          }
        })
      );
    }
    body.appendChild(field('规则组', tags));
    if (active) {
      const list = h('div');
      (active.rules || []).forEach((r, i) => {
        const row = h('div', { class: 'row tight', style: { marginBottom: '3px' } });
        row.appendChild(textInput(r.from, (v) => { r.from = v; markDirty(); }, { placeholder: '错误写法' }));
        row.appendChild(h('span', { text: '→' }));
        row.appendChild(textInput(r.to, (v) => { r.to = v; markDirty(); }, { placeholder: '正确写法' }));
        row.appendChild(
          button('删', () => {
            active.rules.splice(i, 1);
            markDirty();
            render();
          }, { small: true, danger: true })
        );
        list.appendChild(row);
      });
      body.appendChild(field('规则（错误写法 → 正确写法）', list));
      const row = h('div', { class: 'row tight' });
      row.appendChild(
        button('添加规则', () => {
          active.rules = active.rules || [];
          active.rules.push({ from: '', to: '' });
          markDirty();
          render();
        }, { small: true })
      );
      row.appendChild(
        button('新建规则组', () => {
          promptDialog('新建规则组', '我的规则组', (name) => {
            const id = `grp_${Date.now().toString(36)}`;
            d.optimize.groups.push({ id, name: name || '未命名', rules: [] });
            d.optimize.activeGroupId = id;
            markDirty();
            render();
          });
        }, { small: true })
      );
      row.appendChild(
        button('导出', () => {
          downloadFile(`字幕替换规则-${active.name}.json`, exportRuleGroups([active]), 'application/json');
          toast({ title: '已导出规则组' }, 'ok');
        }, { small: true })
      );
      row.appendChild(
        button('导入', () => {
          const input = h('input', { type: 'file', accept: '.json,application/json', style: { display: 'none' } });
          document.body.appendChild(input);
          input.addEventListener('change', async () => {
            const file = input.files && input.files[0];
            input.remove();
            if (!file) return;
            try {
              const text = await file.text();
              const imported = parseRuleGroups(text);
              d.optimize.groups.push(...imported);
              d.optimize.activeGroupId = imported[0].id;
              markDirty();
              render();
              toast({ title: `已导入 ${imported.length} 个规则组` }, 'ok');
            } catch (err) {
              showError(err, '导入规则组失败');
            }
          });
          input.click();
        }, { small: true })
      );
      row.appendChild(
        button('删除规则组', () => {
          d.optimize.groups = d.optimize.groups.filter((g) => g.id !== active.id);
          d.optimize.activeGroupId = (d.optimize.groups[0] || {}).id;
          markDirty();
          render();
        }, { small: true, danger: true, disabled: !!active.builtin })
      );
      body.appendChild(row);
    }
    body.appendChild(
      checkbox(d.optimize.useSearch, (v) => { d.optimize.useSearch = v; markDirty(); }, 'AI 优化时联网核对（把检索结果作为判断依据，消耗额度）')
    );
  });
}

function glossaryGroup(d) {
  return groupWrap('glossary', '术语表（专有名词正确答案）', false, (body) => {
    const list = h('div');
    (d.optimize.glossary || []).forEach((g, i) => {
      const row = h('div', { class: 'row tight', style: { marginBottom: '3px' } });
      row.appendChild(textInput(g.term, (v) => { g.term = v; markDirty(); }, { placeholder: '专有名词' }));
      row.appendChild(textInput(g.note, (v) => { g.note = v; markDirty(); }, { placeholder: '说明（可选）' }));
      row.appendChild(
        button('删', () => {
          d.optimize.glossary.splice(i, 1);
          markDirty();
          render();
        }, { small: true, danger: true })
      );
      list.appendChild(row);
    });
    body.appendChild(field('术语', list));
    body.appendChild(
      button('添加术语', () => {
        d.optimize.glossary = d.optimize.glossary || [];
        d.optimize.glossary.push({ term: '', note: '' });
        markDirty();
        render();
      }, { small: true })
    );
    body.appendChild(h('div', { class: 'note', text: '术语表会随 AI 优化请求一起提交，用于自动纠错。' }));
  });
}

function searchGroup(d) {
  return groupWrap('search', '联网检索（两种方式，作用不同）', false, (body) => {
    body.appendChild(
      h('div', { class: 'note', text: '① 服务商检索：走检索 API，结果会作为 AI 的依据，消耗额度。② 直接搜索引擎：只打开结果页，不消耗额度，不进入 AI 上下文。' })
    );
    body.appendChild(platformPicker('search', d));
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '推荐「DeepSeek 搜索（官方）」：复用你在 AI 平台里填的 DeepSeek Key，不用再填一次；' +
          '结果自带重排分数、权威度、发布时间与 600~800 字摘要，质量明显好于免费网页解析。' +
          '按成功请求计费（$0.75 / 1000 次，失败与空结果不计费）。'
      })
    );
    body.appendChild(
      field(
        '直接搜索引擎',
        select(d.search.engine, SEARCH_ENGINES.map((e) => ({ value: e.id, label: e.label })), (v) => {
          d.search.engine = v;
          markDirty();
        })
      )
    );
    body.appendChild(field('最大结果数', numberInput(d.search.maxResults, (v) => { d.search.maxResults = Math.max(1, Math.min(20, v)); markDirty(); }, { min: 1, max: 20 })));
    body.appendChild(checkbox(d.search.fetchPageContent, (v) => { d.search.fetchPageContent = v; markDirty(); }, '抓取页面正文（更准，但更慢、更耗额度）'));
    body.appendChild(
      checkbox(
        d.search.autoSearchOnChat,
        (v) => { d.search.autoSearchOnChat = v; markDirty(); },
        '对话时自动联网（问题涉及最新/是谁/多少钱/查一下/核实等外部信息时自动检索）'
      )
    );

    // ---- 总结时联网核实 + 视频简介 / 评论 ----
    body.appendChild(h('div', { class: 'section-title', text: '总结时核实与补充' }));
    body.appendChild(
      checkbox(
        d.search.verifyOnSummary !== false,
        (v) => { d.search.verifyOnSummary = v; markDirty(); },
        '生成总结前，对字幕里的术语与事实逐条联网核对'
      )
    );
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '做法：优先让 AI 根据视频标题 + 字幕生成 3~6 条**具体查询**（人名/产品/数字/版本）；\n' +
          '不想多花一次小调用，可关闭上方「用 AI 生成检索词」，改用规则抽取。\n' +
          '生成失败时，再按「每次核实几条」从字幕前 / 中 / 后段抽术语兜底。\n' +
          '每项单独检索，并做**相关性过滤**（与该项毫无词重叠的结果直接丢弃）。\n\n' +
          '校对阶段：模型只用于**校正**字幕里的术语/数字/时间/因果关系错误。\n' +
          '总结阶段：会先把证据整理成 0~3 条简短的「外部补充」，再交给总结模型自然融入；\n' +
          '正文不列来源、不标编号、不出现「待核实」，避免总结变成检索报告。\n\n' +
          '不会抓取整篇网页正文 —— 那样会把上万字无关内容灌进上下文，\n' +
          '把字幕挤成少数派（这是之前版本的问题）。'
      })
    );
    body.appendChild(
      checkbox(
        d.search.aiQueryGeneration !== false,
        (v) => { d.search.aiQueryGeneration = v; markDirty(); },
        '用 AI 生成检索词（更准，但每次总结多一次小模型调用；关闭则只用规则抽取）'
      )
    );
    body.appendChild(
      field(
        '每次核实几条',
        numberInput(d.search.verifyItemCount ?? 12, (v) => {
          d.search.verifyItemCount = Math.max(1, Math.min(16, v));
          markDirty();
        }, { min: 1, max: 16 }),
        '从字幕的前 / 中 / 后段各取候选项（AI 生成查询失败时的兜底数量）'
      )
    );
    const extraQueriesInput = h('textarea', {
      class: 'input',
      rows: 3,
      placeholder: '每行一条，例如：DeepSeek V4 发布时间',
      title: '这些查询会补充到 AI 生成的检索词里'
    });
    extraQueriesInput.value = d.search.extraVerifyQueries || '';
    extraQueriesInput.addEventListener('input', () => {
      d.search.extraVerifyQueries = extraQueriesInput.value;
      markDirty();
    });
    body.appendChild(
      field(
        '额外核实查询（每行一条）',
        extraQueriesInput,
        'AI 漏掉的关键实体可以在这里补；会与 AI 生成的查询合并、去重'
      )
    );
    body.appendChild(
      checkbox(
        (d.summary && d.summary.useVideoMeta) !== false,
        (v) => { d.summary = d.summary || {}; d.summary.useVideoMeta = v; markDirty(); },
        '总结时带上视频简介（常含补充说明、时间轴、参考链接）'
      )
    );
    body.appendChild(
      checkbox(
        d.summary && d.summary.useComments === true,
        (v) => { d.summary = d.summary || {}; d.summary.useComments = v; markDirty(); },
        '总结时带上热门评论（了解观众关注点；多跑一次接口，评论噪声较大，默认关闭）'
      )
    );
    body.appendChild(
      checkbox(
        d.search.alwaysSearchOnChat,
        (v) => { d.search.alwaysSearchOnChat = v; markDirty(); },
        '每轮对话都联网检索（最准，但每问一句都会消耗检索额度）'
      )
    );

    // ---- 免费无 Key 引擎（开箱即用）----
    body.appendChild(h('div', { class: 'section-title', text: '免费引擎（无需 Key）' }));
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '没配检索 Key 时自动使用这些公开引擎 —— 装了扩展就能联网，不必先注册任何服务。\n' +
          '已实测可用：Bing 网页 / AnySearch / Exa（MCP 匿名端点）。\n' +
          '它们是第三方公开服务，不保证长期稳定与额度，所以只作兜底：\n' +
          '配置了自己的检索平台时优先用配置的，它失败才回退到这里。'
      })
    );
    body.appendChild(
      checkbox(
        d.search.keylessFallback !== false,
        (v) => { d.search.keylessFallback = v; markDirty(); },
        '允许使用免费引擎兜底（关闭后：没配 Key 就无法联网）'
      )
    );
    body.appendChild(
      field(
        '结果缓存（分钟，0 = 关闭）',
        numberInput(d.search.cacheMinutes ?? 5, (v) => {
          d.search.cacheMinutes = Math.max(0, Math.min(60, v));
          markDirty();
        }, { min: 0, max: 60, step: 1 })
      )
    );
    body.appendChild(h('div', { class: 'note', text: '同一问题重复提问时直接命中缓存，不再消耗检索额度。' }));

    const st = store.get();
    if ((st.search.results || []).length) {
      body.appendChild(h('div', { class: 'section-title', text: `检索来源面板（${st.search.results.length} 条）` }));
      sortSources(st).forEach((r, i) => {
        body.appendChild(
          h('div', { class: 'src-row' }, [
            h('span', { class: 'cite-count', text: `×${r.__count}` }),
            h('a', { class: 'md-link', href: r.url, target: '_blank', rel: 'noreferrer', text: r.title || r.url }),
            h('span', { class: 'muted', text: (r.snippet || '').slice(0, 60) })
          ])
        );
      });
    }
    // ---- 时间过滤 ----
    body.appendChild(h('div', { class: 'section-title', text: '时间范围' }));
    body.appendChild(
      field(
        '默认时间范围',
        select(
          TIME_PRESETS.some((p) => p.id === (d.search.timeRange || ''))
            ? d.search.timeRange || ''
            : (d.search.timeRange ? '__custom' : ''),
          [
            ...TIME_PRESETS.map((p) => ({ value: p.id, label: p.label })),
            { value: '__custom', label: '自定义（相对时间或绝对日期）' }
          ],
          (v) => {
            if (v === '__custom') {
              const cur = String(d.search.timeRange || '');
              d.search.timeRange = TIME_PRESETS.some((p) => p.id === cur) ? '3d' : cur;
            } else {
              d.search.timeRange = v;
            }
            markDirty();
            render();
          }
        )
      )
    );
    // 自定义输入：支持 12h / 3d / 2w / 6mo / 1y，或绝对日期 2026-01-01（表示该日期之后）
    const customVal = String(d.search.timeRange || '');
    const isCustom = customVal && !TIME_PRESETS.some((p) => p.id === customVal);
    if (isCustom) {
      const tr = normalizeTimeRange(customVal);
      body.appendChild(
        field(
          '自定义时间范围',
          h('input', {
            class: 'input',
            value: customVal,
            placeholder: '例如 3d（近三天）、2w、6mo、2026-01-01',
            oninput: (e) => {
              d.search.timeRange = e.target.value.trim();
              markDirty();
            }
          })
        )
      );
      body.appendChild(
        h('div', {
          class: 'note',
          text: tr
            ? `解析为「${tr.label}」`
            : '无法识别的写法 —— 支持 12h / 3d / 2w / 6mo / 1y，或绝对日期 2026-01-01'
        })
      );
    }
    body.appendChild(
      h('div', {
        class: 'note',
        text:
          '⚠ 免费引擎（Bing 网页 / AnySearch / Exa 匿名端点）实测无法按时间过滤 ——\n' +
          'URL 参数与日期参数都会被服务端忽略。\n' +
          '要严格的时间范围，请配置 Tavily / Exa / 博查 / 智谱 / 秘塔 等检索平台。\n' +
          '本扩展不会假装过滤生效：未生效时结果里会明确标注。'
      })
    );

    const row = h('div', { class: 'row tight' });
    const input = h('input', { class: 'input', placeholder: '检索关键词…', value: st.search.query || '', style: { flex: '1 1 auto' } });
    row.appendChild(input);
    row.appendChild(button('服务商检索', () => doProviderSearch(input.value), { small: true, primary: true, title: '结果会进入 AI 依据（消耗额度）' }));
    row.appendChild(button('直接搜索', () => doEngineSearch(input.value), { small: true, title: '只打开搜索引擎结果页（不消耗额度）' }));
    body.appendChild(field('立即检索', row));
  });
}

function sortSources(st) {
  const results = st.search.results || [];
  const counts = st.search.counts || {};
  return results
    .map((r) => ({ ...r, __count: counts[r.url] || 0 }))
    .sort((a, b) => b.__count - a.__count);
}

function exportGroup(d) {
  return groupWrap('export', '导出（6 格式 × 4 模板）', false, (body) => {
    body.appendChild(
      field(
        '默认格式',
        select(d.exportCfg.format, EXPORT_FORMATS.map((f) => ({ value: f.id, label: f.label })), (v) => {
          d.exportCfg.format = v;
          markDirty();
        })
      )
    );
    body.appendChild(
      field(
        '字幕模板',
        select(d.exportCfg.template, EXPORT_TEMPLATES.map((t) => ({ value: t.id, label: `${t.label} — ${t.desc}` })), (v) => {
          d.exportCfg.template = v;
          markDirty();
        })
      )
    );
    body.appendChild(checkbox(d.exportCfg.includeTimestamps, (v) => { d.exportCfg.includeTimestamps = v; markDirty(); }, '正文里保留时间戳'));
    body.appendChild(checkbox(d.exportCfg.estimateTimestamps, (v) => { d.exportCfg.estimateTimestamps = v; markDirty(); }, '缺少时间戳时自动估算'));
    body.appendChild(field('ASS 字号', numberInput(d.exportCfg.assFontSize, (v) => { d.exportCfg.assFontSize = v; markDirty(); }, { min: 12, max: 120 })));
    body.appendChild(field('文件名模板', textInput(d.exportCfg.filenamePattern, (v) => { d.exportCfg.filenamePattern = v; markDirty(); }, { placeholder: '{title}-{part}' }), '可用占位符：{title} {part} {bvid} {date}'));
  });
}

function batchGroup(d) {
  return groupWrap('batch', '批量队列（支持合集 / 单个视频）', false, (body) => {
    const input = h('textarea', {
      class: 'input',
      // 存在 ui.batchInput 里：排队/暂停/移除都会重绘设置页，
      // 以前写了一半的链接会被清空。
      value: store.get().ui.batchInput || '',
      placeholder:
        '每行一个链接。支持：\n' +
        '· 普通视频：https://www.bilibili.com/video/BV...\n' +
        '· 合集：https://space.bilibili.com/<mid>/channel/collectiondetail?sid=<id>\n' +
        '  （也支持 /lists/<id>）\n' +
        '可以混着填。'
    });
    input.addEventListener('input', () => {
      store.get().ui.batchInput = input.value;
    });
    const clearInput = () => {
      input.value = '';
      store.get().ui.batchInput = '';
    };
    body.appendChild(field('视频 / 合集链接', input));

    // 展开预览区：点「展开合集」后在这里列出解析结果，
    // 让用户**看着清单**决定是全加还是挑着加（用户要求「也支持一个个处理」）。
    let pending = [];
    const preview = h('div', { class: 'row tight', style: { flexDirection: 'column', alignItems: 'stretch' } });
    const renderPreview = () => {
      clear(preview);
      if (!pending.length) return;
      const hasCollection = pending.some((v) => v.fromCollection);
      preview.appendChild(
        h('div', {
          class: 'section-title',
          text: `解析到 ${pending.length} 个视频${hasCollection ? '（含合集）' : ''}`
        })
      );
      // 先展示前若干个，避免几百条把设置页撑爆
      const shown = pending.slice(0, 200);
      for (const v of shown) {
        preview.appendChild(
          h('div', { class: 'queue-row' }, [
            h('div', { class: 't', text: v.title || v.url }),
            h('div', {
              class: 'muted',
              text: [v.fromCollection ? `合集：${v.seasonTitle || '未命名'}` : '单个视频', v.bvid || '', v.duration ? `${Math.round(v.duration / 60)} 分钟` : '']
                .filter(Boolean)
                .join(' · ')
            })
          ])
        );
      }
      if (pending.length > shown.length) {
        preview.appendChild(h('div', { class: 'note', text: `其余 ${pending.length - shown.length} 个未展示，但都会加入队列。` }));
      }
      preview.appendChild(
        h('div', { class: 'row tight' }, [
          button(
            `全部加入队列（${pending.length}）`,
            () => {
              const added = pending.length;
              batchAdd(pending.map((v) => v.url).join('\n'));
              pending = [];
              clearInput();
              renderPreview();
              render();
              toast({ title: `已加入 ${added} 个视频到队列`, detail: '在下方「队列」里可以看到进度' }, 'ok');
            },
            { small: true, primary: true }
          ),
          button(
            '取消',
            () => {
              pending = [];
              renderPreview();
            },
            { small: true }
          )
        ])
      );
    };
    body.appendChild(preview);

    body.appendChild(
      h('div', { class: 'row tight' }, [
        button(
          '展开 / 加入队列',
          async () => {
            const text = input.value.trim();
            if (!text) {
              toast({ title: '请先粘贴链接' }, 'warn');
              return;
            }
            // 没有合集链接就按原样入队，不必多一步
            if (!/bilibili\.com\/.*(collectiondetail|seriesdetail|\/lists\/)/.test(text)) {
              batchAdd(text);
              clearInput();
              render();
              return;
            }
            const res = await expandCollectionsFromText(text);
            if (!res.ok || !res.videos.length) {
              toast(
                { title: '没能解析到视频', detail: (res.metas || []).map((m) => m.reason).filter(Boolean).join('；') || res.reason || '请检查链接' },
                'warn',
                6000
              );
              return;
            }
            pending = res.videos;
            // 只解析出一个视频（且不是合集）时直接入队
            if (pending.length === 1 && !pending[0].fromCollection) {
              batchAdd(pending[0].url);
              pending = [];
              clearInput();
              render();
              return;
            }
            renderPreview();
          },
          { small: true, primary: true, title: '普通视频直接入队；合集会先展开成清单，由你确认' }
        ),
        button(
          '直接入队（不展开）',
          () => {
            batchAdd(input.value);
            clearInput();
            pending = [];
            renderPreview();
            render();
          },
          { small: true, title: '把每行当成一个链接直接排队（合集链接会失败，因为队列需要视频链接）' }
        )
      ])
    );

    const st = store.get();
    const q = st.queue || [];
    const hasQueued = q.some((x) => x.status === 'queued');
    const hasRunning = q.some((x) => x.status === 'running');
    const hasDone = q.some((x) => x.status === 'done' || x.status === 'error' || x.status === 'cancelled');
    if (q.length) {
      body.appendChild(h('div', { class: 'section-title', text: `队列（${q.filter((x) => x.status === 'queued').length} 待处理 / 共 ${q.length}）` }));
      for (const item of q) {
        body.appendChild(
          h('div', { class: 'queue-row' }, [
            h('div', { class: 't', text: item.title || item.url }),
            h('div', { class: 'muted', text: `状态：${statusLabel(item.status)}${item.error ? ` —— ${item.error}` : ''}` }),
            h('div', { class: 'row tight' }, [
              item.status === 'running' || item.status === 'cancelling'
                ? h('span', { class: 'pill', text: `${Math.round(item.progress || 0)}%` })
                : null,
              item.status === 'running'
                ? button('取消', () => batchCancel(item.id), {
                    small: true,
                    danger: true,
                    title: '中止这一条的抓取/处理，继续队列里的下一条'
                  })
                : item.status === 'cancelling'
                  ? button('取消中…', () => {}, { small: true, disabled: true })
                  : button('移除', () => batchRemove(item.id), {
                      small: true,
                      danger: true,
                      title: '从队列移除'
                    })
            ])
          ])
        );
      }
    }
    body.appendChild(
      h('div', { class: 'row tight' }, [
        button('暂停队列', () => batchPause(true), {
          small: true,
          disabled: !hasQueued && !hasRunning,
          title: '当前正在处理的视频会先完成，之后不再开始下一条'
        }),
        button('继续队列', () => batchPause(false), {
          small: true,
          disabled: !app.batch.paused,
          title: '继续处理排队中的视频'
        }),
        button('清空已完成', () => batchClearDone(), {
          small: true,
          disabled: !hasDone,
          title: '移除已完成与失败的条目'
        })
      ])
    );
    if (app.batch.paused) {
      body.appendChild(h('div', { class: 'note', text: '队列已暂停：当前这条会完成，之后不会自动开始下一条。' }));
    }
  });
}

function statusLabel(s) {
  return { queued: '排队中', running: '处理中', cancelling: '正在取消', cancelled: '已取消', done: '已完成', error: '失败' }[s] || s;
}

function historyGroup(d) {
  return groupWrap('history', '历史记录（查看 / 删除 / 清空）', false, (body) => {
    const st = store.get();
    const rows = st.history || [];
    const head = h('div', { class: 'row tight' });
    head.appendChild(button('刷新', () => loadHistory(), { small: true }));
    head.appendChild(
      button('清空全部', () => {
        confirmDialog('清空历史', '确定清空全部历史记录？此操作不可撤销。', () => clearHistory());
      }, { small: true, danger: true })
    );
    head.appendChild(
      button('清空缓存', () => {
        confirmDialog('清空缓存', '确定清空字幕缓存与音频分块缓存？下次会重新下载。', async () => {
          await call('cache.clear');
          toast({ title: '缓存已清空' }, 'ok');
          render();
        });
      }, { small: true })
    );
    body.appendChild(head);
    if (!rows.length) body.appendChild(h('div', { class: 'note', text: '还没有历史记录。抓取字幕后会自动保存。' }));
    for (const r of rows) {
      body.appendChild(
        h('div', { class: 'history-row' }, [
          h('div', { class: 't', text: `${r.video?.title || '未命名'}${r.video?.partTitle ? ` · ${r.video.partTitle}` : ''}` }),
          h('div', { class: 'muted', text: `${r.video?.bvid || ''} · ${r.source === 'asr' ? '语音转录' : '官方字幕'} · ${r.lines ? r.lines.length : 0} 行 · ${fmtRelative(r.savedAt)}` }),
          h('div', { class: 'row tight' }, [
            button('恢复', () => restoreHistory(r.key), { small: true }),
            button('删除', () => removeHistory(r.key), { small: true, danger: true })
          ])
        ])
      );
    }
    body.appendChild(checkbox(d.behavior.useLocalCache, (v) => { d.behavior.useLocalCache = v; markDirty(); }, '优先使用本地缓存（避免重复花费）'));
    body.appendChild(checkbox(d.behavior.preferOfficial, (v) => { d.behavior.preferOfficial = v; markDirty(); }, '优先使用官方字幕'));
  });
}

function pageGroup(d) {
  return groupWrap('page', '页面内功能', false, (body) => {
    body.appendChild(checkbox(d.page.playerButton, (v) => { d.page.playerButton = v; markDirty(); }, '在播放器上显示「字幕」按钮'));
    body.appendChild(field('按钮触发时使用的提示词', textInput(d.page.playerButtonPrompt, (v) => { d.page.playerButtonPrompt = v; markDirty(); })));
    body.appendChild(checkbox(d.page.overlay, (v) => { d.page.overlay = v; markDirty(); }, '在视频画面上显示字幕'));
    body.appendChild(
      field('画面字幕字号缩放', numberInput(d.page.overlayFontScale, (v) => { d.page.overlayFontScale = Math.max(0.5, Math.min(3, v)); markDirty(); }, { min: 0.5, max: 3, step: 0.1 }))
    );
    body.appendChild(field('画面字幕距底部（%）', numberInput(d.page.overlayBottom, (v) => { d.page.overlayBottom = Math.max(0, Math.min(60, v)); markDirty(); }, { min: 0, max: 60 })));
    body.appendChild(checkbox(d.page.followPlayback, (v) => { d.page.followPlayback = v; markDirty(); }, '跟随播放（把播放时间回传给侧边栏高亮）'));
    body.appendChild(
      button('把当前设置推送到页面', async () => {
        await persistDraft({ silent: true });
        toast({ title: '已推送到 B 站页面' }, 'ok');
      }, { small: true })
    );
  });
}

function updateSection(d) {
  const status = h('div', { class: 'note', text: '正在读取更新信息…' });
  const meta = h('div', { class: 'muted', text: '' });
  const details = h('details', { class: 'update-notes', style: { marginTop: '6px', display: 'none' } });
  const pre = h('pre', {
    style: {
      whiteSpace: 'pre-wrap',
      maxHeight: '240px',
      overflow: 'auto',
      fontSize: '12px',
      lineHeight: '1.5',
      margin: '4px 0 0'
    },
    text: ''
  });
  details.appendChild(h('summary', { text: '新版本说明' }));
  details.appendChild(pre);

  let current = null;

  const openBtn = button(
    '打开下载页',
    async () => {
      const url =
        (current && current.release && current.release.htmlUrl) ||
        (current && current.releaseUrl) ||
        'https://github.com/Universe366/bilibili-subtitle-assistant/releases';
      try {
        await call('tab.open', { url });
      } catch (err) {
        showError(err, '打开下载页失败');
      }
    },
    { small: true }
  );

  const checkBtn = button(
    '检查更新',
    () => load(true),
    { small: true, primary: true }
  );

  const skipBtn = button(
    '跳过此版本',
    async () => {
      const version = current && current.skipped ? '' : (current && current.latest) || '';
      if (!version && !(current && current.skipped)) return;
      try {
        await call('update.skip', { version });
        await load(true);
        toast({ title: version ? `已跳过 v${version}` : '已恢复该版本的更新提醒' }, 'ok', 3000);
      } catch (err) {
        showError(err, '更新跳过设置失败');
      }
    },
    { small: true }
  );
  skipBtn.style.display = 'none';

  const backupBtn = button('先备份设置', () => exportSettingsBackup(), {
    small: true,
    title: '导出当前全部设置（含 API Key 明文），更新后可按需导入'
  });

  // 手动加载的扩展不会自动更新。更新方式直接决定设置会不会丢：
  // 覆盖原目录 → 扩展 ID 不变 → chrome.storage 里的设置还在；
  // 解压到新目录 → ID 变化 → 旧设置读不到。这里把步骤写在界面上。
  const howto = h('details', { class: 'update-notes', style: { marginTop: '6px' } });
  howto.appendChild(h('summary', { text: '更新步骤（不丢设置）' }));
  howto.appendChild(
    h('ol', { style: { margin: '6px 0 0 18px', padding: '0' } }, [
      h('li', { text: '先点「先备份设置」，保存导出的 JSON（含 API Key 明文，请妥善保管）。' }),
      h('li', {
        text: '下载 zip，解压并覆盖原来的 bilibili-subtitle-assistant 目录（manifest.json 所在层）；不要加载到新文件夹。'
      }),
      h('li', { text: '打开 chrome://extensions，点扩展卡片上的刷新；不要移除扩展。' }),
      h('li', { text: '刷新所有已打开的 B 站页面。' }),
      h('li', {
        text: '如果确实换了目录导致设置丢失，到「诊断与关于 → 设置备份」导入刚才的 JSON。'
      })
    ])
  );

  const updateNote = h('div', {
    class: 'note',
    text:
      '手动加载的扩展不会自动更新。覆盖原目录时扩展 ID 不变，chrome.storage 里的设置会保留；' +
      '加载到新目录会改变扩展 ID，旧设置将读不到。'
  });
  const idLine = h('div', {
    class: 'muted',
    text: `当前扩展 ID：${(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) || '-'}`
  });

  function renderState(out) {
    if (!out) {
      status.textContent = '尚未检查';
      return;
    }
    if (out.skipped) {
      status.textContent = `已跳过 v${out.latest}（可点「取消跳过」恢复提醒）`;
    } else if (out.hasUpdate) {
      status.textContent = `发现新版本 v${out.latest}（当前 v${out.current}）`;
      details.open = true;
    } else if (out.ok) {
      status.textContent = `已是最新版本 v${out.latest}`;
    } else if (out.reason === 'disabled') {
      status.textContent = '自动检查已关闭（仍可手动检查）';
    } else if (out.reason === 'not-found') {
      status.textContent = '无法检查：GitHub 仓库未公开，或还没有发布 Release';
    } else if (out.reason === 'rate-limit') {
      status.textContent = '无法检查：GitHub API 限流，请稍后再试';
    } else {
      status.textContent = `检查失败：${out.message || out.reason || '未知原因'}`;
    }
    if (out.hasUpdate || out.skipped) {
      skipBtn.style.display = '';
      skipBtn.textContent = out.skipped ? '取消跳过' : '跳过此版本';
    } else {
      skipBtn.style.display = 'none';
    }
    const tabBtn = document.querySelector('[data-tab-btn="settings"]');
    const gear = document.getElementById('btn-settings');
    if (out.hasUpdate) {
      if (tabBtn) tabBtn.setAttribute('data-update', 'true');
      if (gear) {
        gear.setAttribute('data-update', 'true');
        gear.setAttribute('title', `设置（发现新版本 v${out.latest}）`);
      }
    } else {
      if (tabBtn) tabBtn.removeAttribute('data-update');
      if (gear) {
        gear.removeAttribute('data-update');
        gear.setAttribute('title', '设置');
      }
    }
    meta.textContent = out.checkedAt ? `上次检查：${fmtRelative(out.checkedAt)}` : '尚未检查';
    const notes = out.release && out.release.notes ? String(out.release.notes) : '';
    if (notes) {
      pre.textContent = notes.slice(0, 12000);
      details.style.display = '';
    } else {
      pre.textContent = '该版本没有填写说明。';
      details.style.display = '';
    }
  }

  async function load(manual) {
    checkBtn.disabled = true;
    status.textContent = manual ? '正在检查新版本…' : '正在读取更新信息…';
    try {
      let out = manual ? null : await call('update.state');
      if (!out || !out.checkedAt) {
        out = await call('update.check', { manual: !!manual }, { timeoutMs: 30000 });
      }
      current = out;
      renderState(out);
      if (manual && out && out.ok) {
        toast(
          {
            title: out.hasUpdate ? `发现新版本 v${out.latest}` : '已是最新版本',
            detail: out.hasUpdate
              ? '更新前建议先备份设置，并覆盖原目录；可点「打开下载页」查看说明并下载。'
              : ''
          },
          out.hasUpdate ? 'ok' : 'info',
          4000
        );
      }
    } catch (err) {
      status.textContent = `检查失败：${(err && err.message) || '网络请求失败'}`;
    } finally {
      checkBtn.disabled = false;
    }
  }

  const box = h('div', { class: 'update-box' }, [
    h('div', { class: 'section-title', text: '版本更新' }),
    status,
    meta,
    idLine,
    updateNote,
    h('div', { class: 'row tight', style: { marginTop: '6px' } }, [checkBtn, skipBtn, openBtn, backupBtn]),
    checkbox(
      (d.update && d.update.autoCheck) !== false,
      (v) => {
        d.update = d.update || {};
        d.update.autoCheck = v;
        markDirty();
      },
      '自动检查更新（每天一次，保存设置后生效）'
    ),
    details,
    howto
  ]);

  load(false);
  return box;
}

function advancedGroup(d) {
  return groupWrap('advanced', '诊断与关于', false, (body) => {
    const st = store.get();
    const b = st.build;
    body.appendChild(updateSection(d));
    body.appendChild(settingsBackupSection());
    body.appendChild(
      h('div', { class: 'kv' }, [
        h('span', { class: 'kv-key', text: '构建指纹' }),
        h('span', { class: 'kv-val', text: b ? `${b.version} + ${b.modules} 模块 + ${b.buildTime}` : '加载中…' })
      ])
    );
    body.appendChild(h('div', { class: 'kv' }, [h('span', { class: 'kv-key', text: '内容脚本版本' }), h('span', { class: 'kv-val', text: (b && b.contentVersion) || '-' })]));
    const tabs = st.contentTabs || [];
    body.appendChild(h('div', { class: 'section-title', text: '页面脚本检查（扩展更新后旧页面需要刷新）' }));
    if (!tabs.length) body.appendChild(h('div', { class: 'note', text: '没检测到 B 站标签页。' }));
    for (const t of tabs) {
      body.appendChild(
        h('div', { class: 'history-row' }, [
          h('div', { class: 't', text: t.title || t.url }),
          h('div', { class: 'muted', text: `脚本版本：${t.scriptVersion || '未注入'}${t.stale ? '（版本不一致，需要刷新页面）' : ''}` }),
          h('div', { class: 'row tight' }, [
            button('重新注入', async () => {
              try {
                await call('page.reinject', { tabId: t.tabId }, { timeoutMs: 20000 });
                toast({ title: '已重新注入内容脚本' }, 'ok');
                refreshTabs();
              } catch (err) {
                showError(err, '重新注入失败');
              }
            }, { small: true }),
            button('刷新页面', async () => {
              try {
                await call('tab.reload', { tabId: t.tabId }, { timeoutMs: 15000 });
                toast({ title: '已刷新页面', detail: '旧的主环境脚本会被新版本替换。' }, 'ok', 4000);
              } catch (err) {
                showError(err, '刷新页面失败');
              }
            }, { small: true })
          ])
        ])
      );
    }
    body.appendChild(button('重新检查', () => refreshTabs(), { small: true }));
    body.appendChild(
      h('div', { class: 'row tight', style: { marginTop: '8px' } }, [
        button('复制诊断信息', async () => {
          try {
            const diag = await call('diagnostics');
            await copyText(JSON.stringify(diag, null, 2));
            toast({ title: '诊断信息已复制到剪贴板' }, 'ok');
          } catch (err) {
            showError(err, '复制诊断信息失败');
          }
        }, { small: true, primary: true }),
        button('查看诊断', () => diagnosticsDialog(), { small: true })
      ])
    );
    body.appendChild(field('字幕缓存保留天数', numberInput(store.get().settings.cache.subtitleTtlDays, (v) => { d.cache.subtitleTtlDays = Math.max(0, v); markDirty(); }, { min: 0, max: 999 })));
  });
}

async function refreshTabs() {
  try {
    const out = await call('page.refresh');
    store.set({ contentTabs: out.tabs || [] });
    render();
  } catch (err) {
    /* ignore */
  }
}

// ---------------------------------------------------------------------------
// 保存 / 重置
// ---------------------------------------------------------------------------

async function persistDraft(opts = {}) {
  const d = draft();
  const saved = await saveSettings(d);
  state.draft = structuredCloneSafe(saved);
  state.dirty = false;
  renderToolbar();
  return saved;
}

async function save() {
  try {
    await persistDraft({ silent: true });
    const saved = await call('settings.get');
    store.set({ settings: saved, readiness: saved.__readiness || { ok: {}, issues: [] } });
    toast({ title: '设置已保存', detail: '密钥等敏感信息只保存在本机。' }, 'ok');
    render();
  } catch (err) {
    showError(err, '保存设置失败');
  }
}

async function reload() {
  const saved = await loadSettings();
  state.draft = structuredCloneSafe(saved);
  state.dirty = false;
  store.set({ settings: saved, readiness: saved.__readiness || { ok: {}, issues: [] } });
  render();
  toast({ title: '已放弃未保存的改动' }, 'ok', 1600);
}

function resetAll() {
  confirmDialog('重置全部设置', '会把所有平台、提示词、规则组恢复为默认值（API Key 也会被清空）。确定继续？', async () => {
    const saved = await call('settings.reset');
    state.draft = structuredCloneSafe(saved);
    state.dirty = false;
    store.set({ settings: saved, readiness: saved.__readiness || { ok: {}, issues: [] } });
    render();
    toast({ title: '已重置为默认设置' }, 'ok');
  });
}

// ---------------------------------------------------------------------------
// 设置备份 / 恢复
// ---------------------------------------------------------------------------
//
// 背景：手动加载的扩展，chrome.storage.local 是按扩展 ID 存的。
// 覆盖原目录更新时 ID 不变，设置会保留；如果解压到新目录再加载，ID 变了，
// 旧设置就读不到。导出/导入是这种情况下的兜底，也方便换机器。

async function exportSettingsBackup() {
  confirmDialog(
    '导出设置备份',
    '备份文件包含 API Key 明文，请只保存在本机，不要上传到公开位置。确定导出？',
    async () => {
      try {
        const out = await call('settings.export', {}, { timeoutMs: 15000 });
        const stamp = new Date().toISOString().slice(0, 10);
        downloadFile(`bsub-settings-${stamp}.json`, JSON.stringify(out, null, 2), 'application/json');
        toast(
          {
            title: '已导出设置备份',
            detail: '文件包含 API Key 明文，请妥善保存。'
          },
          'warn',
          6500
        );
      } catch (err) {
        showError(err, '导出设置失败');
      }
    }
  );
}

function importSettingsBackup() {
  const input = h('input', {
    type: 'file',
    accept: '.json,application/json',
    style: { display: 'none' }
  });
  input.addEventListener('change', async () => {
    const file = input.files && input.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const backup = data && data.kind === 'bsub-settings-backup' ? data : { settings: data };
      if (!backup.settings || typeof backup.settings !== 'object' || Array.isArray(backup.settings)) {
        throw new Error('文件里没有可识别的设置数据');
      }
      confirmDialog(
        '导入设置备份',
        '会覆盖当前设置；备份里没有的 API Key 会保留当前值。确定继续？',
        async () => {
          try {
            const saved = await call('settings.import', { backup }, { timeoutMs: 20000 });
            state.draft = structuredCloneSafe(saved);
            state.dirty = false;
            store.set({ settings: saved, readiness: saved.__readiness || { ok: {}, issues: [] } });
            render();
            toast({ title: '设置已导入', detail: 'API Key 只保存在本机。' }, 'ok', 4000);
          } catch (err) {
            showError(err, '导入设置失败');
          }
        }
      );
    } catch (err) {
      showError(err, '导入设置失败');
    } finally {
      input.value = '';
    }
  });
  document.body.appendChild(input);
  input.click();
  setTimeout(() => input.remove(), 60000);
}

function settingsBackupSection() {
  return h('div', {}, [
    h('div', { class: 'section-title', text: '设置备份（更新前建议导出）' }),
    h('div', {
      class: 'note',
      text: '导出文件包含 API Key 明文，只保存在本机；导入会覆盖当前设置，备份里没有的 Key 会保留。'
    }),
    h('div', { class: 'row tight' }, [
      button('导出设置', () => exportSettingsBackup(), { small: true }),
      button('导入设置', () => importSettingsBackup(), { small: true })
    ])
  ]);
}

// ---------------------------------------------------------------------------
// 诊断浮层
// ---------------------------------------------------------------------------

export async function diagnosticsDialog() {
  const body = h('div');
  body.appendChild(h('div', { class: 'note', text: '加载中…' }));
  const ov = openOverlay('诊断信息', body, [
    {
      label: '复制全部',
      primary: true,
      onClick: async () => {
        try {
          const diag = await call('diagnostics');
          await copyText(JSON.stringify(diag, null, 2));
          toast({ title: '已复制' }, 'ok');
        } catch (err) {
          showError(err);
        }
      }
    },
    { label: '关闭', onClick: () => closeOverlays() }
  ], { width: '520px' });
  try {
    const diag = await call('diagnostics');
    store.set({ diagnostics: diag });
    clear(body);
    const rows = [
      ['扩展版本', `${diag.extensionVersion}（Manifest V${diag.manifestVersion}）`],
      ['内容脚本版本', diag.contentVersion],
      ['模块数 / 构建时间', `${diag.modules} / ${diag.buildTime}`],
      ['缓存', `字幕 ${diag.cache.subtitleCount} 条（${fmtBytes(diag.cache.approxBytes)}）· 音频 ${diag.cache.audioCount} · 历史 ${diag.cache.historyCount}`],
      ['用户代理', diag.userAgent]
    ];
    for (const [k, v] of rows) body.appendChild(h('div', { class: 'kv' }, [h('span', { class: 'kv-key', text: k }), h('span', { class: 'kv-val', text: String(v) })]));
    body.appendChild(h('div', { class: 'section-title', text: '平台配置（密钥只显示是否已配置）' }));
    for (const [kind, list] of Object.entries(diag.platformSummary || {})) {
      for (const p of list) {
        body.appendChild(
          h('div', { class: 'kv' }, [
            h('span', { class: 'kv-key', text: `${kind} · ${p.name}${p.active ? '（当前）' : ''}` }),
            h('span', { class: 'kv-val', text: `Key:${p.keySet ? '已配置' : '未配置'} 模型:${p.model || '-'} 地址:${p.baseUrl || '-'}` })
          ])
        );
      }
    }
    body.appendChild(h('div', { class: 'section-title', text: '已授权域名' }));
    for (const o of (diag.permissions && diag.permissions.origins) || []) {
      const row = h('div', { class: 'kv' }, [
        h('span', { class: 'kv-key', text: o }),
        button(
          '撤销',
          async () => {
            try {
              const r = await call('permission.revoke', { url: o }, { timeoutMs: 10000 });
              if (r && r.removed) {
                row.remove();
                toast({ title: '已撤销该域名权限' }, 'ok', 3000);
              } else {
                toast({ title: '该权限是必需的，无法撤销' }, 'warn', 3500);
              }
            } catch (err) {
              showError(err, '撤销权限失败');
            }
          },
          { small: true, danger: true, title: '撤销自定义接口域名的访问权限' }
        )
      ]);
      body.appendChild(row);
    }
    body.appendChild(
      h('div', {
        class: 'note',
        text: 'B 站、AI/ASR 等必需域名无法撤销；这里主要用来回收自定义接口的权限。'
      })
    );
  } catch (err) {
    clear(body);
    body.appendChild(h('div', { text: '读取诊断信息失败：' + (err.payload?.detail || err.message) }));
  }
  return ov;
}
